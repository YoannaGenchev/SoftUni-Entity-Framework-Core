﻿using System.Text;
using System.Xml.Serialization;
using ProductShop.Data;
using ProductShop.DTOs.Import;
using ProductShop.DTOs.Export;
using ProductShop.Models;
using Microsoft.EntityFrameworkCore;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            using var context = new ProductShopContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            string categoryProductsXml = File.ReadAllText("../../../Datasets/categories-products.xml");
            Console.WriteLine(ImportCategoryProducts(context, categoryProductsXml));
        }

        private static T Deserialize<T>(string inputXml, string rootName)
        {
            var serializer = new XmlSerializer(typeof(T), new XmlRootAttribute(rootName));
            using var reader = new StringReader(inputXml);
            return (T)serializer.Deserialize(reader)!;
        }

        private static string Serialize<T>(T obj, string rootName)
        {
            var serializer = new XmlSerializer(typeof(T), new XmlRootAttribute(rootName));
            var namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            using var writer = new StringWriter();
            serializer.Serialize(writer, obj, namespaces);
            return writer.ToString();
        }

        public static string ImportCategoryProducts(ProductShopContext context, string inputXml)
        {
            var cpDtos = Deserialize<ImportCategoryProductDto[]>(inputXml, "CategoryProducts");

            var validCategoryIds = context.Categories.Select(c => c.Id).ToHashSet();
            var validProductIds = context.Products.Select(p => p.Id).ToHashSet();

            var categoryProducts = cpDtos
                .Where(cp => validCategoryIds.Contains(cp.CategoryId) &&
                             validProductIds.Contains(cp.ProductId))
                .Select(cp => new CategoryProduct
                {
                    CategoryId = cp.CategoryId,
                    ProductId = cp.ProductId
                })
                .ToArray();

            context.CategoryProducts.AddRange(categoryProducts);
            context.SaveChanges();

            return $"Successfully imported {categoryProducts.Length}";
        }


    }
}