﻿using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.DTOs.Export;
using CarDealer.Models;
using System.Text;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using var context = new CarDealerContext();
        }


        public static string ImportSales(CarDealerContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ImportSaleDto[]),
                new XmlRootAttribute("Sales"));

            ImportSaleDto[] saleDtos;
            using (StringReader reader = new StringReader(inputXml))
            {
                saleDtos = (ImportSaleDto[])serializer.Deserialize(reader)!;
            }

            var carIds = context.Cars.Select(c => c.Id).ToHashSet();

            var sales = saleDtos
                .Where(dto => carIds.Contains(dto.CarId))
                .Select(dto => new Sale
                {
                    CarId = dto.CarId,
                    CustomerId = dto.CustomerId,
                    Discount = dto.Discount
                }).ToArray();

            context.Sales.AddRange(sales);
            context.SaveChanges();

            return $"Successfully imported {sales.Length}";
        }


        // Helper method 
        private static string SerializeToXml<T>(T[] objects, string rootName)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T[]),
                new XmlRootAttribute(rootName));

            StringBuilder sb = new StringBuilder();
            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            using (StringWriter writer = new StringWriter(sb))
            {
                serializer.Serialize(writer, objects, namespaces);
            }

            return sb.ToString().TrimEnd();
        }
    }
}