﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=CarDealer;Integrated Security=True;Encrypt=False";
    }
}
