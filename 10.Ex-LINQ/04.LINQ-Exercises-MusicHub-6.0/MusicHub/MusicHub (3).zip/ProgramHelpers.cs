﻿internal static class ProgramHelpers
{
    private static void Main(string[] args)
    {
    }
}