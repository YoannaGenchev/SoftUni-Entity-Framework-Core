﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=localhost,1433;Database=Cadastre;User Id=sa;Password=S0ftUn!2025;TrustServerCertificate=True";
    }
}
