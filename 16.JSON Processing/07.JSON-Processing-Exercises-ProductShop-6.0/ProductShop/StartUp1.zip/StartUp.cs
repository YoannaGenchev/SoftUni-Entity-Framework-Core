﻿using System.Text.Json;
using ProductShop.Data;
using ProductShop.Models;
using ProductShop.DTOs.Import;
using ProductShop.DTOs.Export;
using Microsoft.EntityFrameworkCore;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            using ProductShopContext context = new ProductShopContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            string usersJson = File.ReadAllText("../../../Datasets/users.json");
            Console.WriteLine(ImportUsers(context, usersJson));

            string productsJson = File.ReadAllText("../../../Datasets/products.json");
            Console.WriteLine(ImportProducts(context, productsJson));

            string categoriesJson = File.ReadAllText("../../../Datasets/categories.json");
            Console.WriteLine(ImportCategories(context, categoriesJson));

            string categoryProductsJson = File.ReadAllText("../../../Datasets/categories-products.json");
            Console.WriteLine(ImportCategoryProducts(context, categoryProductsJson));
        }
        private static bool ImportCategoryProducts(ProductShopContext context, string categoryProductsJson)
        {
            throw new NotImplementedException();
        }

        private static bool ImportCategories(ProductShopContext context, string categoriesJson)
        {
            throw new NotImplementedException();
        }

        private static bool ImportProducts(ProductShopContext context, string productsJson)
        {
            throw new NotImplementedException();
        }

        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            var userDtos = JsonSerializer.Deserialize<List<ImportUserDto>>(inputJson);

            var users = userDtos
                .Select(dto => new User
                {
                    FirstName = dto.FirstName,
                    LastName = dto.LastName,
                    Age = dto.Age
                })
                .ToList();

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count}";
        }
    }
}