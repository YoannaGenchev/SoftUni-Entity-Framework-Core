﻿using System.Text.Json;
using ProductShop.Data;
using ProductShop.Models;
using ProductShop.DTOs.Import;
using ProductShop.DTOs.Export;
using Microsoft.EntityFrameworkCore;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            using ProductShopContext context = new ProductShopContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            //string usersJson = File.ReadAllText("../../../Datasets/users.json");
            //Console.WriteLine(ImportUsers(context, usersJson));

            //string productsJson = File.ReadAllText("../../../Datasets/products.json");
            //Console.WriteLine(ImportProducts(context, productsJson));

            //string categoriesJson = File.ReadAllText("../../../Datasets/categories.json");
            //Console.WriteLine(ImportCategories(context, categoriesJson));

            string categoryProductsJson = File.ReadAllText("../../../Datasets/categories-products.json");
            Console.WriteLine(ImportCategoryProducts(context, categoryProductsJson));
        }
  

        /*        public static string ImportUsers(ProductShopContext context, string inputJson)
                {
                    var userDtos = JsonSerializer.Deserialize<List<ImportUserDto>>(inputJson);

                    var users = userDtos
                        .Select(dto => new User
                        {
                            FirstName = dto.FirstName,
                            LastName = dto.LastName,
                            Age = dto.Age
                        })
                        .ToList();

                    context.Users.AddRange(users);
                    context.SaveChanges();

                    return $"Successfully imported {users.Count}";
                }*/

        /*public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            var productDtos = JsonSerializer.Deserialize<List<ImportProductDto>>(inputJson);

            var products = productDtos
                .Select(dto => new Product
                {
                    Name = dto.Name,
                    Price = dto.Price,
                    SellerId = dto.SellerId,
                    BuyerId = dto.BuyerId
                })
                .ToList();

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Count}";
        }*/

        /*    public static string ImportCategories(ProductShopContext context, string inputJson)
            {
                var categoryDtos = JsonSerializer.Deserialize<List<ImportCategoryDto>>(inputJson);

                var categories = categoryDtos
                    .Where(dto => dto.Name != null) // Skip null names
                    .Select(dto => new Category
                    {
                        Name = dto.Name!
                    })
                    .ToList();

                context.Categories.AddRange(categories);
                context.SaveChanges();

                return $"Successfully imported {categories.Count}";
            }*/

        public static string ImportCategoryProducts(ProductShopContext context, string inputJson)
        {
            var categoryProductDtos = JsonSerializer.Deserialize<List<ImportCategoryProductDto>>(inputJson);

            var categoryProducts = categoryProductDtos
                .Select(dto => new CategoryProduct
                {
                    CategoryId = dto.CategoryId,
                    ProductId = dto.ProductId
                })
                .ToList();

            context.CategoriesProducts.AddRange(categoryProducts);
            context.SaveChanges();

            return $"Successfully imported {categoryProducts.Count}";
        }
    }
}