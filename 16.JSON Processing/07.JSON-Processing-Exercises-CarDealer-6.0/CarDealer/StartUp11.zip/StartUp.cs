﻿using System.Text.Json;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.DTOs.Export;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using var context = new CarDealerContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();


            string carsJson = File.ReadAllText("../../../Datasets/cars.json");
            Console.WriteLine(ImportCars(context, carsJson));

        }

        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            var carDtos = JsonSerializer.Deserialize<List<ImportCarDto>>(inputJson);

            var validPartIds = context.Parts
                .Select(p => p.Id)
                .ToHashSet();

            var cars = new List<Car>();

            foreach (var dto in carDtos!)
            {
                var car = new Car
                {
                    Make = dto.Make,
                    Model = dto.Model,
                    TraveledDistance = dto.TraveledDistance
                };

                foreach (var partId in dto.PartsId.Distinct())
                {
                    if (validPartIds.Contains(partId))
                    {
                        car.PartsCars.Add(new PartCar { PartId = partId });
                    }
                }

                cars.Add(car);
            }

            context.Cars.AddRange(cars);
            context.SaveChanges();

            return $"Successfully imported {cars.Count}.";
        }


    }
}