﻿using System.Text.Json;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.DTOs.Export;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using var context = new CarDealerContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();


            string customersJson = File.ReadAllText("../../../Datasets/customers.json");
            Console.WriteLine(ImportCustomers(context, customersJson));

        }

        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            var customerDtos = JsonSerializer.Deserialize<List<ImportCustomerDto>>(inputJson);

            var customers = customerDtos!
                .Select(c => new Customer
                {
                    Name = c.Name,
                    BirthDate = c.BirthDate,
                    IsYoungDriver = c.IsYoungDriver
                })
                .ToList();

            context.Customers.AddRange(customers);
            context.SaveChanges();

            return $"Successfully imported {customers.Count}.";
        }



    }
}