﻿using System.Text.Json;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.DTOs.Export;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using var context = new CarDealerContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();


            string salesJson = File.ReadAllText("../../../Datasets/sales.json");
            Console.WriteLine(ImportSales(context, salesJson));

        }

        public static string ImportSales(CarDealerContext context, string inputJson)
        {
            var saleDtos = JsonSerializer.Deserialize<List<ImportSaleDto>>(inputJson);

            var sales = saleDtos!
                .Select(s => new Sale
                {
                    CarId = s.CarId,
                    CustomerId = s.CustomerId,
                    Discount = s.Discount
                })
                .ToList();

            context.Sales.AddRange(sales);
            context.SaveChanges();

            return $"Successfully imported {sales.Count}.";
        }

    }
}