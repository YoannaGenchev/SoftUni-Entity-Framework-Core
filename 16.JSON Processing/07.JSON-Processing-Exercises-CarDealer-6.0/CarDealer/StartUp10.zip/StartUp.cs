﻿using System.Text.Json;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.DTOs.Export;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using var context = new CarDealerContext();

            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();


            string partsJson = File.ReadAllText("../../../Datasets/parts.json");
            Console.WriteLine(ImportParts(context, partsJson));

        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var partDtos = JsonSerializer.Deserialize<List<ImportPartDto>>(inputJson);

            var validSupplierIds = context.Suppliers
                .Select(s => s.Id)
                .ToHashSet();

            var parts = partDtos!
                .Where(p => validSupplierIds.Contains(p.SupplierId))
                .Select(p => new Part
                {
                    Name = p.Name,
                    Price = p.Price,
                    Quantity = p.Quantity,
                    SupplierId = p.SupplierId
                })
                .ToList();

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count}.";
        }

    }
}