﻿internal class ExportPatientDto
{
    public object FullName { get; set; }
    public object AgeGroup { get; set; }
    public int Gender { get; set; }
    public object Medicines { get; set; }
}